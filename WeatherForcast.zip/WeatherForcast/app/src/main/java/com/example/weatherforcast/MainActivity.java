package com.example.weatherforcast;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    public static AutoCompleteTextView cityName;
    public static Button search;
    public static TextView rWeather;
    public static ImageView image;

    private static final String[] CITIES = new String[] {
            // US Cities
            "New York", "Los Angeles", "Chicago", "Houston", "Phoenix",
            "Philadelphia", "San Antonio", "San Diego", "Dallas", "San Jose",
            "Austin", "Jacksonville", "Fort Worth", "Columbus", "Charlotte",
            "San Francisco", "Indianapolis", "Seattle", "Denver", "Washington",
            "Boston", "El Paso", "Nashville", "Detroit", "Oklahoma City",
            "Portland", "Las Vegas", "Memphis", "Louisville", "Baltimore",
            "Milwaukee", "Albuquerque", "Tucson", "Fresno", "Mesa",
            "Sacramento", "Atlanta", "Kansas City", "Colorado Springs", "Miami",
            "Raleigh", "Omaha", "Long Beach", "Virginia Beach", "Oakland",
            "Minneapolis", "Tulsa", "Arlington", "Tampa", "New Orleans",
            // Indian Cities
            "Mumbai", "Delhi", "Bangalore", "Hyderabad", "Ahmedabad",
            "Chennai", "Kolkata", "Surat", "Pune", "Jaipur",
            "Lucknow", "Kanpur", "Nagpur", "Visakhapatnam", "Bhopal",
            "Patna", "Ludhiana", "Agra", "Nashik", "Faridabad",
            "Meerut", "Rajkot", "Kalyan", "Vasai", "Varanasi",
            "Srinagar", "Aurangabad", "Dhanbad", "Amritsar", "Navi Mumbai",
            "Allahabad", "Howrah", "Ranchi", "Gwalior", "Jabalpur",
            "Coimbatore", "Vijayawada", "Jodhpur", "Madurai", "Raipur",
            "Kota", "Guwahati", "Chandigarh", "Solapur", "Hubballi",
            "Mysore", "Tiruchirappalli", "Bareilly", "Aligarh", "Tiruppur"
    };

    class getWeather extends AsyncTask<String, Void, String> {
        protected String doInBackground(String... urls) {
            StringBuilder result = new StringBuilder();
            try {
                URL url = new URL(urls[0]);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.connect();

                InputStream inputStream = urlConnection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line).append("\n");
                }

                return result.toString();
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            try {
                JSONObject jsonObject = new JSONObject(result);

                // Check if it's a current weather response or forecast
                if (jsonObject.has("main")) {
                    // Current weather data
                    JSONObject mainObject = jsonObject.getJSONObject("main");
                    JSONArray weatherArray = jsonObject.getJSONArray("weather");
                    JSONObject weatherObject = weatherArray.getJSONObject(0);

                    String weatherDescription = weatherObject.getString("main");
                    image.setImageResource(getWeatherIcon(weatherDescription));

                    String weatherInfo = "Current Weather:\n";
                    weatherInfo += "Weather : " + weatherDescription + "\n";
                    weatherInfo += "Description : " + weatherObject.getString("description") + "\n";
                    weatherInfo += "Temperature : " + kelvinToCelsius(mainObject.getDouble("temp")) + "°C\n";
                    weatherInfo += "Humidity : " + mainObject.getDouble("humidity") + "%\n";
                    rWeather.setText(weatherInfo);

                } else if (jsonObject.has("list")) {
                    // Forecast data (assuming 'list' contains forecast items)
                    JSONArray listArray = jsonObject.getJSONArray("list");
                    StringBuilder forecastInfo = new StringBuilder("Weather Forecast:\n");

                    for (int i = 0; i < 5; i++) {
                        JSONObject forecastItem = listArray.getJSONObject(i);
                        JSONObject mainObject = forecastItem.getJSONObject("main");
                        JSONArray weatherArray = forecastItem.getJSONArray("weather");
                        JSONObject weatherObject = weatherArray.getJSONObject(0);

                        String weatherDescription = weatherObject.getString("main");
                        if (i == 0) { // Set image for the first forecast item
                            image.setImageResource(getWeatherIcon(weatherDescription));
                        }

                        forecastInfo.append("Date: ").append(forecastItem.getString("dt_txt")).append("\n");
                        forecastInfo.append("Weather : ").append(weatherDescription).append("\n");
                        forecastInfo.append("Description : ").append(weatherObject.getString("description")).append("\n");
                        forecastInfo.append("Temperature : ").append(kelvinToCelsius(mainObject.getDouble("temp"))).append("°C\n");
                        forecastInfo.append("Temperature Max : ").append(kelvinToCelsius(mainObject.getDouble("temp_max"))).append("°C\n");
                        forecastInfo.append("Humidity : ").append(mainObject.getDouble("humidity")).append("%\n");
                        forecastInfo.append("\n");
                    }

                    rWeather.setText(forecastInfo.toString());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private String kelvinToCelsius(double kelvin) {
            return String.format("%.2f", kelvin - 273.15);
        }

        private int getWeatherIcon(String weatherDescription) {
            switch (weatherDescription.toLowerCase()) {
                case "clear":
                    return R.drawable.clear;
                case "rain":
                    return R.drawable.rain;
                case "snow":
                    return R.drawable.snow;
                case "clouds":
                    return R.drawable.cloud1;
                // Add more cases as needed
                default:
                    return R.drawable.default_weather;
            }
        }
    }

    private String getForecastUrl(String city) {
        return "https://api.openweathermap.org/data/2.5/forecast?q=" + city + "&appid=edb433f482f3dde6d9c445b5f77c1e71";
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        cityName = findViewById(R.id.cityName);
        search = findViewById(R.id.buttonSearch);
        rWeather = findViewById(R.id.resultWeather);
        image = findViewById(R.id.image);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, CITIES);
        cityName.setAdapter(adapter);

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Button Clicked!!", Toast.LENGTH_SHORT).show();
                String city = cityName.getText().toString();
                if (city != null && !city.isEmpty()) {
                    // URL for current weather
                    String currentWeatherUrl = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=edb433f482f3dde6d9c445b5f77c1e71";
                    // URL for forecast
                    String forecastUrl = getForecastUrl(city);

                    // Execute current weather task
                    getWeather currentWeatherTask = new getWeather();
                    currentWeatherTask.execute(currentWeatherUrl);

                    // Execute forecast task
                    getWeather forecastTask = new getWeather();
                    forecastTask.execute(forecastUrl);
                } else {
                    rWeather.setText("Enter valid city");
                    Toast.makeText(MainActivity.this, "Enter Valid City", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
